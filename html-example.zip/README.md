# Two-column full width responsive layout

View demo: http://russmaxdesign.github.io/example-layout-two-full/

This is a basic HTML template that uses the [Bootstrap framework](http://getbootstrap.com/). All key Bootstrap files have been included so you can begin creating layouts as needed.

Created by [Russ Weakley](https://twitter.com/russmaxdesign), [Max Design](http://maxdesign.com.au/). See [Licence information](LICENCE) for use.
